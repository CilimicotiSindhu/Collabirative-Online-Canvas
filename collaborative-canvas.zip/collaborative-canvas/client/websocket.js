// client/websocket.js
(function(){
  const socket = io();

  const state = {
    roomId: 'lobby',
    userId: null,
    usersById: {},     // { socketId: { id, name, color } }
    latency: null,
    rooms: []          // [{ id, count }]
  };

  const byId = (arr)=> { const m={}; arr.forEach(u=> m[u.id]=u); return m; };

  /* ---------------- JOIN / ROOM SYNC ---------------- */
  // We do NOT auto-join. main.js will call WS.join()

  socket.on('joined', ({ roomId, userId, users, snapshot })=>{
    state.roomId = roomId;
    state.userId = userId;
    state.usersById = byId(users);
    // hydrate canvas
    window.CanvasAPI.ingestSnapshot(snapshot);
    renderUsers(users);
  });

  socket.on('users', ({ users })=>{
    state.usersById = byId(users);
    renderUsers(users);
  });

  /* ---------------- ROOMS DROPDOWN ---------------- */
  socket.on('rooms', ({ rooms })=>{
    state.rooms = rooms || [];
    renderRooms();
  });

  socket.on('connect', ()=> socket.emit('rooms:request'));

  function renderRooms(){
    const sel = document.getElementById('room-select');
    if (!sel) return;
    const old = sel.value;
    sel.innerHTML = '';
    state.rooms.forEach(r=>{
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.id} (${r.count})`;
      sel.appendChild(opt);
    });
    if (old && [...sel.options].some(o=>o.value===old)) sel.value = old;
  }

  /* ---------------- STROKES / UNDO ---------------- */
  socket.on('stroke:new', ({ op }) => window.CanvasAPI.ingestOp(op));
  socket.on('undo:applied', (p)     => window.CanvasAPI.applyUndo(p));
  socket.on('redo:applied', (p)     => window.CanvasAPI.applyRedo(p));

  /* ---------------- CURSORS (remote + local) ---------------- */
  const cursors = document.getElementById('cursors');
  const nodes = new Map(); // socketId -> wrapper

  function upsertCursor(userId){
    let wrap = nodes.get(userId);
    if (!wrap){
      wrap = document.createElement('div');
      wrap.style.position = 'absolute';
      const dot = document.createElement('div'); dot.className = 'cursor-dot';
      const label = document.createElement('div'); label.className = 'cursor-label';
      wrap.appendChild(dot); wrap.appendChild(label);
      cursors.appendChild(wrap);
      nodes.set(userId, wrap);
    }
    return wrap;
  }

  function paintCursor(userId, x, y){
    const wrap = upsertCursor(userId);
    const user = state.usersById[userId];
    const color = user?.color || '#10b981';
    const name  = (userId === state.userId)
      ? (user?.name ? `${user.name} (you)` : 'you')
      : (user?.name || userId.slice(0,4));

    wrap.querySelector('.cursor-dot').style.background = color;
    const label = wrap.querySelector('.cursor-label');
    label.textContent = name;
    label.style.border = `1px solid ${color}`;
    wrap.style.left = x + 'px';
    wrap.style.top  = y + 'px';
    wrap.style.opacity = '1';
    clearTimeout(wrap._fade);
    wrap._fade = setTimeout(()=> wrap.style.opacity = '0.65', 400);
  }

  // remote peers
  socket.on('cursor', ({ userId, x, y })=> paintCursor(userId, x, y));

  /* ---------------- LATENCY (RTT) ---------------- */
  setInterval(()=>{
    const t = performance.now();
    socket.timeout(2000).emit('ping', {}, ()=>{
      state.latency = Math.round(performance.now() - t);
      updateStats();
    });
  }, 3000);

  function updateStats(){
    const el = document.getElementById('stats');
    if (!el) return;
    const n = Object.keys(state.usersById).length;
    el.textContent = `room: ${state.roomId} • users: ${n}` + (state.latency!=null ? ` • ${state.latency}ms` : '');
  }

  function renderUsers(users){
    const ul = document.getElementById('user-list');
    if (!ul) return;
    ul.innerHTML = '';
    users.forEach(u=>{
      const li = document.createElement('li');
      li.textContent = (u.id === state.userId ? `${u.name} (you)` : u.name);
      li.style.borderLeft = `10px solid ${u.color}`;
      ul.appendChild(li);
    });
    updateStats();
  }

  /* ---------------- PUBLIC API ---------------- */
  window.WS = {
    join: ({ roomId, name, color }) => socket.emit('join', { roomId, name, color }),
    updateUser: (patch) => socket.emit('user:update', patch),

    strokeStart: (p) => socket.emit('stroke:start', p),
    strokeChunk: (p) => socket.emit('stroke:chunk', p),
    strokeEnd:   (p) => socket.emit('stroke:end', p),

    undo: () => socket.emit('undo'),
    redo: () => socket.emit('redo'),

    cursor: (point) => socket.emit('cursor', point),

    // show your own cursor/name locally (so you see "you")
    localCursor: (p) => {
      if (!state.userId) return;
      paintCursor(state.userId, p.x, p.y);
    },
  };
})();
