// client/canvas.js
// Canvas drawing logic, smoothing and efficient rendering
(function () {
  const DPR = Math.max(1, Math.floor(window.devicePixelRatio || 1));
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d', { alpha: true });

  let tool = 'brush';
  let color = '#1f6feb';
  let width = 6;

  const ops = [];          // {id,type:'stroke',points,tool,color,width}
  const undone = new Set();

  // rAF coalesced repaint
  let needsRepaint = false;
  function requestRepaint(){
    if (!needsRepaint){
      needsRepaint = true;
      requestAnimationFrame(()=>{ needsRepaint = false; redrawAll(); });
    }
  }

  // Resize canvas to fit container with DPR
  function resize() {
    const rect = canvas.getBoundingClientRect();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    canvas.width  = Math.floor(rect.width  * DPR);
    canvas.height = Math.floor(rect.height * DPR);
    ctx.scale(DPR, DPR);
    redrawAll();
  }
  window.addEventListener('resize', () => requestAnimationFrame(resize));
  setTimeout(resize);

  // Stroke renderer with midpoint quadratic smoothing
  function drawStroke(ctx, stroke) {
    if (!stroke.points || stroke.points.length < 2) return;
    ctx.save();
    if (stroke.tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = stroke.color || '#000';
    }
    ctx.lineWidth = stroke.width || 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const pts = stroke.points;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length - 1; i++) {
      const midX = (pts[i].x + pts[i + 1].x) / 2;
      const midY = (pts[i].y + pts[i + 1].y) / 2;
      ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
    }
    ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
    ctx.stroke();
    ctx.restore();
  }

  function redrawAll() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const op of ops) {
      if (op.type === 'stroke' && !undone.has(op.id)) {
        drawStroke(ctx, op);
      }
    }
  }

  // ===== Input handling (pointer) with batching =====
  let drawing = false;
  let current = null;     // active stroke
  let buffered = [];      // batched points to send
  let lastSent = 0;

  function pt(e) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      t: performance.now()
    };
  }

  function start(e) {
    drawing = true;
    current = {
      id: crypto.randomUUID(),
      type: 'stroke',
      tool,
      color,
      width,
      points: [pt(e)]
    };
    ops.push(current);
    window.WS.strokeStart({
      id: current.id,
      tool,
      color,
      width,
      point: current.points[0]
    });
  }

  function move(e) {
    if (!drawing) return;
    const p = pt(e);

    // --- Point coalescing: skip nearly-identical points (bandwidth saver) ---
    if (buffered.length) {
      const last = buffered[buffered.length - 1];
      const dx = p.x - last.x, dy = p.y - last.y;
      if ((dx*dx + dy*dy) >= 2) {
        current.points.push(p);
        // Local low-latency draw incremental segment
        drawStroke(ctx, { ...current, points: current.points.slice(-3) });
        buffered.push(p);
      }
    } else {
      current.points.push(p);
      drawStroke(ctx, { ...current, points: current.points.slice(-3) });
      buffered.push(p);
    }
    // ------------------------------------------------------------------------

    const now = performance.now();
    if (now - lastSent > 16 && buffered.length) { // ~60fps batching
      window.WS.strokeChunk({ id: current.id, points: buffered });
      buffered = [];
      lastSent = now;
    }

    // Send to peers and show your own cursor locally
    window.WS.cursor(p);
    window.WS.localCursor(p); // <-- show your own cursor label on your tab
  }

  function end() {
    if (!drawing) return;
    drawing = false;
    if (buffered.length) {
      window.WS.strokeChunk({ id: current.id, points: buffered });
      buffered = [];
    }
    window.WS.strokeEnd({ id: current.id });
    current = null;
  }

  canvas.addEventListener('pointerdown', start);
  canvas.addEventListener('pointermove', move);
  window.addEventListener('pointerup', end);
  canvas.addEventListener('pointerleave', end);

  // ===== Public API for other modules =====
  window.CanvasAPI = {
    setTool:  (t) => { tool = t; },
    setColor: (c) => { color = c; },
    setWidth: (w) => { width = Number(w); },
    clearLocal: () => { ops.length = 0; undone.clear(); requestRepaint(); },

    // Incoming network ops
    ingestSnapshot: (snapshot) => {
      ops.length = 0; undone.clear();
      for (const op of snapshot.ops) ops.push(op);
      for (const id of snapshot.undone) undone.add(id);
      requestRepaint();
    },
    ingestOp: (op) => {
      const idx = ops.findIndex(o => o.id === op.id);
      if (idx === -1) ops.push(op); else ops[idx] = op; // idempotent
      requestRepaint();
    },
    applyUndo: ({ opId }) => { undone.add(opId); requestRepaint(); },
    applyRedo: ({ opId }) => { undone.delete(opId); requestRepaint(); },
  };
})();
