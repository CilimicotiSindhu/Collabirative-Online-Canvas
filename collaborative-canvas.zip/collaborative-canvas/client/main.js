// client/main.js
(function () {
  // ---------- Local storage helpers ----------
  const LS = { room: 'cc_room', name: 'cc_name', color: 'cc_color' };
  const getLS = (k, d = '') => localStorage.getItem(k) || d;
  const setLS = (k, v) => (v != null) && localStorage.setItem(k, v);

  // ---------- DOM ----------
  const roomInput = document.getElementById('room-id');
  const nameInput = document.getElementById('user-name');
  const joinBtn   = document.getElementById('join-btn');
  const roomSelect= document.getElementById('room-select');

  const swatches  = document.querySelectorAll('.swatch');
  const tools     = document.querySelectorAll('.tool');
  const widthEl   = document.getElementById('width');
  const widthTxt  = document.getElementById('width-readout');

  // ---------- Init defaults from LS / Query ----------
  const qs = new URLSearchParams(location.search);
  let selectedUserColor =
    qs.get('color') ||
    getLS(LS.color) ||
    '#1f6feb';

  const initRoom = qs.get('room') || getLS(LS.room) || '';
  const initName = qs.get('name') || getLS(LS.name) || '';

  if (roomInput) roomInput.value = initRoom;
  if (nameInput) nameInput.value = initName;

  
  window.CanvasAPI.setColor(selectedUserColor);

  // ---------- Color swatches ----------
  function highlightSwatch(hex) {
    swatches.forEach(s => s.classList.toggle('selected', s.dataset.color === hex));
  }
  highlightSwatch(selectedUserColor);

  swatches.forEach(el => {
    el.addEventListener('click', () => {
      const hex = el.dataset.color;
      selectedUserColor = hex;
      // Brush color
      window.CanvasAPI.setColor(hex);
      highlightSwatch(hex);
      setLS(LS.color, hex);
      // Live identity color update
      window.WS.updateUser({ color: hex });
    });
  });

  // ---------- Tools ----------
  tools.forEach(btn => {
    btn.addEventListener('click', () => {
      tools.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const toolName = (btn.id === 'tool-eraser') ? 'eraser' : 'brush';
      window.CanvasAPI.setTool(toolName);
    });
  });

  // ---------- Width ----------
  if (widthEl && widthTxt) {
    widthTxt.textContent = `width: ${widthEl.value}`;
    widthEl.addEventListener('input', () => {
      window.CanvasAPI.setWidth(widthEl.value);
      widthTxt.textContent = `width: ${widthEl.value}`;
    });
  }

  // ---------- Undo / Redo ----------
  document.getElementById('undo')?.addEventListener('click', () => window.WS.undo());
  document.getElementById('redo')?.addEventListener('click', () => window.WS.redo());

  // ---------- Join helpers ----------
  function doJoin(room, name, color) {
    const safeRoom = (room || 'lobby').trim();
    const safeName = (name || 'guest').trim();
    setLS(LS.room, safeRoom);
    setLS(LS.name, safeName);
    setLS(LS.color, color || selectedUserColor);
    window.WS.join({ roomId: safeRoom, name: safeName, color: color || selectedUserColor });
  }

  // Join button
  joinBtn?.addEventListener('click', () => {
    doJoin(roomInput?.value, nameInput?.value, selectedUserColor);
  });

  // Rooms dropdown: join immediately when picked
  roomSelect?.addEventListener('change', () => {
    const chosen = roomSelect.value;
    if (!chosen) return;
    if (roomInput) roomInput.value = chosen;
    doJoin(chosen, nameInput?.value, selectedUserColor);
  });

  // Name change → live update (no rejoin needed)
  nameInput?.addEventListener('change', () => {
    const name = (nameInput.value || 'guest').trim();
    setLS(LS.name, name);
    window.WS.updateUser({ name });
  });

  // ---------- Auto-join if URL or LS provided ----------
  if (qs.get('room') || qs.get('name') || initRoom || initName) {
    doJoin(initRoom, initName, selectedUserColor);
  }
})();
