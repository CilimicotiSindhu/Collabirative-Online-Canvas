// server/server.js
const path = require('path');
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const { Rooms } = require('./rooms');
const { DrawingState } = require('./drawing-state');

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, '..', 'client')));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const rooms = new Rooms();
const state = new DrawingState();

// Helper: broadcast current rooms for the dropdown
function emitRooms() {
  io.emit('rooms', { rooms: rooms.summaries() });
}

// Palette for per-user identity colors (cursor/online chip)
const palette = ['#1f6feb','#ef4444','#22c55e','#eab308','#a855f7','#06b6d4','#111827'];
const pickColor = (i) => palette[i % palette.length];

io.on('connection', (socket) => {
  let roomId = 'lobby';

  // -------- JOIN a room --------
  socket.on('join', (payload = {}) => {
    roomId = payload.roomId || 'lobby';

    // choose a color (or use client-provided)
    const existing = rooms.listUsers(roomId);
    const color = payload.color || pickColor(existing.length);

    const userObj = {
      id: socket.id,
      name: payload.name || `user-${socket.id.slice(0,4)}`,
      color
    };

    socket.join(roomId);
    rooms.join(roomId, socket, userObj);

    // send full snapshot to the new user
    const snapshot = state.snapshot(roomId);
    io.to(socket.id).emit('joined', {
      roomId,
      userId: socket.id,
      users: rooms.listUsers(roomId), // [{id,name,color}]
      snapshot
    });

    // update everyone
    io.to(roomId).emit('users', { users: rooms.listUsers(roomId) });
    emitRooms();
  });

  // -------- Live identity updates (name/color) --------
  socket.on('user:update', (patch = {}) => {
    const updated = rooms.updateUser(roomId, socket.id, patch);
    if (updated) {
      io.to(roomId).emit('users', { users: rooms.listUsers(roomId) });
    }
  });

  // -------- Strokes: start / chunk / end --------
  socket.on('stroke:start', (s) => {
    const op = state.addStroke(roomId, {
      id: s.id,
      userId: socket.id,
      tool: s.tool,          // 'brush' | 'eraser'
      color: s.color,
      width: s.width,
      points: s.point ? [s.point] : [],
      ts: Date.now(),
    });
    io.to(roomId).emit('stroke:new', { op });
  });

  socket.on('stroke:chunk', ({ id, points }) => {
    // Simple back-pressure: cap chunk size
    const MAX_POINTS = 200;
    if (!Array.isArray(points) || points.length === 0) return;
    const pts = points.length > MAX_POINTS ? points.slice(-MAX_POINTS) : points;

    // Append to op (ops are ordered; this preserves overlap semantics)
    const snap = state.snapshot(roomId);
    const op = snap.ops.find(o => o.id === id);
    if (!op) return;
    op.points.push(...pts);
    io.to(roomId).emit('stroke:new', { op });
  });

  socket.on('stroke:end', () => { /* chunks already finalized the op */ });

  // -------- Global Undo/Redo (room-scoped) --------
  let lastUndo = 0, lastRedo = 0; // rate-limit spam
  socket.on('undo', () => {
    if (Date.now() - lastUndo < 100) return;
    lastUndo = Date.now();
    const res = state.undo(roomId);
    if (res) io.to(roomId).emit('undo:applied', res);
  });

  socket.on('redo', () => {
    if (Date.now() - lastRedo < 100) return;
    lastRedo = Date.now();
    const res = state.redo(roomId);
    if (res) io.to(roomId).emit('redo:applied', res);
  });

  // -------- Cursor streaming --------
  socket.on('cursor', (c) => {
    state.cursorUpdate(roomId, socket.id, c);
    socket.to(roomId).emit('cursor', { userId: socket.id, ...c });
  });

  // -------- Rooms list for dropdown --------
  socket.on('rooms:request', () => emitRooms());

  // -------- Latency ping (client RTT display) --------
  socket.on('ping', (_d, ack) => ack && ack());

  // -------- Disconnect cleanup --------
  socket.on('disconnect', () => {
    rooms.leave(roomId, socket);
    io.to(roomId).emit('users', { users: rooms.listUsers(roomId) });
    emitRooms();
  });
});

// ------- Start server -------
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n✔ Collaborative Canvas running on http://localhost:${PORT}`);
});
