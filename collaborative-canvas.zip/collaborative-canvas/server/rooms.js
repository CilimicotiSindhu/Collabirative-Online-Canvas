// server/rooms.js
class Rooms {
  constructor() {
    // roomId -> { users: Map<socketId, {id, name, color}>, createdAt }
    this.rooms = new Map();
  }

  ensure(roomId) {
    if (!this.rooms.has(roomId)) {
      this.rooms.set(roomId, { users: new Map(), createdAt: Date.now() });
    }
    return this.rooms.get(roomId);
  }

  join(roomId, socket, userObj) {
    const room = this.ensure(roomId);
    room.users.set(socket.id, userObj);
    return room;
  }

  leave(roomId, socket) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    room.users.delete(socket.id);
    if (room.users.size === 0) this.rooms.delete(roomId);
  }

  listUsers(roomId) {
    const room = this.rooms.get(roomId);
    return room ? Array.from(room.users.values()) : [];
  }

  getUser(roomId, socketId) {
    const room = this.rooms.get(roomId);
    if (!room) return null;
    return room.users.get(socketId) || null;
  }

  // Live update of a user (e.g., name/color change)
  updateUser(roomId, socketId, patch = {}) {
    const room = this.rooms.get(roomId);
    if (!room) return null;
    const current = room.users.get(socketId);
    if (!current) return null;
    const next = { ...current, ...patch };
    room.users.set(socketId, next);
    return next;
  }

  // For the Rooms dropdown: [{ id, count }]
  summaries() {
    return Array.from(this.rooms.entries()).map(([id, r]) => ({
      id,
      count: r.users.size,
    }));
  }
}

module.exports = { Rooms };
