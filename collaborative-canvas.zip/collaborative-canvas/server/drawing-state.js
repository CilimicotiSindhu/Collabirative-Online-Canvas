// server/drawing-state.js
const { nanoid } = require('nanoid');

/**
 * Per-room drawing state with CRDT-ish operation log.
 * Ops are immutable; global undo uses tombstones in `undone`.
 */
class DrawingState {
  constructor() {
    // roomId -> { ops:[], undone:Set<string>, cursors: Map<userId, cursor> }
    this.rooms = new Map();
    this.seq = 0; // server-side tiebreaker
  }

  ensure(roomId) {
    if (!this.rooms.has(roomId)) {
      this.rooms.set(roomId, { ops: [], undone: new Set(), cursors: new Map() });
    }
    return this.rooms.get(roomId);
  }

  addStroke(roomId, stroke) {
    const room = this.ensure(roomId);
    const op = {
      id: stroke.id || nanoid(8),
      type: 'stroke',
      userId: stroke.userId,
      tool: stroke.tool,         // 'brush' | 'eraser'
      color: stroke.color,
      width: stroke.width,
      points: stroke.points,     // [{x,y,t}]
      ts: stroke.ts || Date.now(),
      seq: ++this.seq,
    };
    room.ops.push(op);
    return op;
  }

  /** Mark an op as undone (tombstone). */
  undo(roomId) {
    const room = this.ensure(roomId);
    for (let i = room.ops.length - 1; i >= 0; i--) {
      const op = room.ops[i];
      if (op.type === 'stroke' && !room.undone.has(op.id)) {
        room.undone.add(op.id);
        return { opId: op.id };
      }
    }
    return null;
  }

  /** Remove tombstone for most recent undone op. */
  redo(roomId) {
    const room = this.ensure(roomId);
    for (let i = room.ops.length - 1; i >= 0; i--) {
      const op = room.ops[i];
      if (op.type === 'stroke' && room.undone.has(op.id)) {
        room.undone.delete(op.id);
        return { opId: op.id };
      }
    }
    return null;
  }

  cursorUpdate(roomId, userId, cursor) {
    const room = this.ensure(roomId);
    room.cursors.set(userId, { ...cursor, ts: Date.now() });
  }

  snapshot(roomId) {
    const room = this.ensure(roomId);
    return {
      ops: room.ops,
      undone: Array.from(room.undone),
      cursors: Object.fromEntries(room.cursors),
    };
  }
}

module.exports = { DrawingState };
