The system uses a client-server architecture with Socket.IO over WebSocket for bidirectional real-time communication and a server-authoritative operation log for conflict-free collaboration. The server (server.js) runs Express to serve static files and hosts a Socket.IO instance that manages rooms, users, and drawing state. Rooms are managed in rooms.js using a Map of roomId to user Map and metadata, handling join/leave, live name/color updates, and broadcasting room summaries for the dropdown. Drawing state lives in drawing-state.js with per-room arrays of immutable stroke operations and a Set of undone op IDs (tombstone pattern), ensuring deterministic rendering and simple global undo/redo by toggling visibility without mutating history. When a user draws, the client (canvas.js) captures pointer events, batches points, sends stroke:start with first point, then stroke:chunk with coalesced points, and stroke:end; the server appends or updates the op and broadcasts the full updated op so every client renders the exact same curve order. New clients receive a full snapshot on join containing all ops and undone IDs. Cursors are sent on pointermove and rendered in an overlay div with colored dots and name labels. Undo/redo are rate-limited server-side and broadcast as single opId events. All client logic is split into canvas.js for rendering and input, websocket.js for Socket.IO handling and UI sync, and main.js for controls and localStorage. No CRDT library is used — consistency comes from server sequencing and append-only logs. The result is buttery-smooth collaborative drawing with sub-100ms perceived latency, perfect for learning how production whiteboards handle concurrency without complex merging.
Architecture Diagram (ASCII)
text+-----------------+        WebSocket        +-----------------+
|   Browser 1     | <-------------------> |                 |
|  (canvas.js)    |                         |   Server        |
|  (websocket.js) |                         |  (server.js)    |
|  (main.js)      |                         |   ├─ rooms.js   |
+-----------------+                         |   ├─ drawing-   |
         ^                                  |      state.js   |
         |                                  |                 |
         |                                  +-----------------+
         |                                          ^
         |                                          |
         | WebSocket                                | broadcast
         |                                          |
         v                                          v
+-----------------+                         +-----------------+
|   Browser 2     | <-------------------> |   Browser N     |
|   (same files)  |   stroke:new, cursor,   |   (same files)  |
+-----------------+   users, undo/redo     +-----------------+

Client → stroke:start → Server → addStroke() → broadcast stroke:new → All clients ingestOp()
Client → stroke:chunk → Server → append points → broadcast updated op → deterministic redraw
Client → undo → Server → mark last op undone → broadcast undo:applied → hide stroke1.7sFast